# Process-to-Yield Simulation: Dopant Diffusion, Ion Implantation, and Wafer Yield

An independent (non-institutional) research project simulating semiconductor
fabrication process physics and its link to wafer yield economics, built
entirely in Python with no proprietary/paid tools.

This is a **beginner-level educational research project**, not a peer-reviewed
publication. It was built for self-study and as a portfolio piece.

## What this project does

1. **Diffusion doping simulation** (`src/diffusion.py`)
   Solves Fick's second law analytically for predeposition (erfc profile)
   and drive-in (Gaussian profile) steps, including Arrhenius temperature
   dependence of diffusivity.

2. **Ion implantation simulation** (`src/implant.py`)
   Models implant doping profiles using the Gaussian approximation
   (projected range + straggle), with an optional skew correction.

3. **Wafer yield modeling** (`src/yield_models.py`)
   Implements Poisson, Murphy, and Negative Binomial yield models based
   on defect density and die area.

4. **Combined process-to-yield analysis** (`src/combined_demo.py`)
   Sweeps drive-in furnace temperature to quantify junction-depth
   variability, then proposes a simplified (explicitly illustrative)
   model linking that process variability to effective defect density
   and resulting yield.

## Important honesty note

Section 4/5's link between doping-profile variance and defect density
is a **simplified illustrative model I constructed for this project**,
not a validated industrial relationship. All physical constants used
as defaults (D0, Ea, Rp, dRp, etc.) are placeholder values for testing
the code — **replace them with properly cited values** from textbooks
or SRIM tables before treating results as meaningful, and say so clearly
in the paper.

## Requirements

```
pip install -r requirements.txt
```

## Usage

```bash
cd src
python diffusion.py        # generates figures/diffusion_profile.png
python implant.py          # generates figures/implant_profile.png
python yield_models.py     # generates figures/yield_models.png
python combined_demo.py    # generates the two combined-analysis figures
```

## Suggested citations to add (fill in as you research)

- Sze, S.M., *Physics of Semiconductor Devices*
- Plummer, Deal, Griffin, *Silicon VLSI Technology*
- Murphy, B.T., "Cost-size optima of monolithic integrated circuits," 1964
- Stapper, C.H., negative binomial defect clustering model
- SRIM/TRIM tables for Rp/dRp values by dopant and energy

## Project status

Work in progress — built for self-study and MTech application portfolio,
not for publication. Feedback and corrections welcome via issues.

## License

MIT (or your choice)
