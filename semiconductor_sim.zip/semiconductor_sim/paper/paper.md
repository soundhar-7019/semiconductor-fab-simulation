# Process-to-Yield Simulation: Modeling Dopant Diffusion, Ion Implantation, and Their Link to Wafer Yield

**An independent self-study project**
*Not peer-reviewed. Not a research publication. Prepared for self-study and M.Tech application portfolio purposes.*

This project was undertaken independently, without institutional affiliation, professor supervision, or funding, to build a first-principles understanding of semiconductor fabrication physics using only freely available tools. It makes no claim of novel findings and should be read as a demonstration of self-directed technical learning, not as original research.

---

## Abstract

Semiconductor fabrication involves many interdependent process steps, from dopant introduction at the front end to final die yield at the back end. This project builds a simplified, fully open-source simulation pipeline in Python that models two standard doping techniques — thermal diffusion and ion implantation — and connects their process control precision to wafer yield using classical statistical yield models. The goal is not to reproduce industrial-grade TCAD accuracy, but to build a working, physically grounded understanding of how front-end process variability can plausibly propagate into back-end yield outcomes. All simulations are implemented from first principles (Fick's law, Arrhenius kinetics, Gaussian implant theory, and Poisson/Murphy/negative-binomial yield statistics) without access to commercial fabrication tools, licensed TCAD software, or a laboratory. This paper documents the physics, the implementation, the results obtained, and — importantly — the assumptions and limitations of the illustrative process-to-yield link proposed in Section 6.

---

## 1. Introduction

Modern integrated circuit fabrication is a sequence of tightly controlled physical and chemical processes. Two of the earliest and most consequential steps are the introduction of dopant atoms into the silicon substrate — via thermal diffusion or ion implantation — which define the electrical behavior of transistors, and the eventual measurement of wafer yield, which determines the economic viability of the entire process.

Most introductory treatments of fabrication teach these topics in isolation: diffusion and implantation are presented as device-physics problems, while yield modeling is presented as a manufacturing-economics problem. This project's motivation is to treat them as *connected* stages of one pipeline, and to build working simulations of each stage using only freely available tools (Python, NumPy, SciPy), since laboratory or commercial TCAD access was not available.

This is explicitly a **beginner-level, self-study exercise**, not a research contribution. It does not claim novel scientific results. Its purpose is to demonstrate genuine understanding of fabrication physics through hands-on implementation, and to serve as a reproducible, inspectable artifact (hosted on GitHub) for academic portfolio purposes, particularly for graduate (M.Tech) admissions.

---

## 2. Background

### 2.1 Dopant Diffusion

Thermal diffusion introduces dopant atoms into silicon by heating the wafer in the presence of a dopant source. It typically occurs in two steps:

- **Predeposition**: the wafer surface is held at a constant, solubility-limited dopant concentration for a fixed time, producing a complementary error function (erfc) profile.
- **Drive-in**: the dopant source is removed, and the wafer is annealed at a (typically higher) temperature so the existing dose redistributes into the substrate, producing an approximately Gaussian profile.

Both steps are governed by Fick's second law of diffusion, and the diffusivity `D` itself is strongly temperature-dependent, following an Arrhenius relationship.

### 2.2 Ion Implantation

Ion implantation directly accelerates dopant ions into the silicon surface using an electric field. Unlike diffusion, which spreads from the surface inward, implantation deposits a subsurface concentration peak at a characteristic **projected range** `Rp`, with a spread described by the **straggle** `ΔRp`. The simplest model treats the resulting profile as Gaussian; more accurate treatments (e.g., Pearson-IV distributions, or full Monte Carlo tools like SRIM) capture the inherent asymmetry of real implant profiles.

### 2.3 Wafer Yield Modeling

Wafer yield — the fraction of manufactured dies that function correctly — depends on defect density (`D0`) and die area (`A`). Several statistical models exist:

- **Poisson model**: assumes uniformly random defect distribution.
- **Murphy's model**: accounts for defect density variation across the wafer.
- **Negative binomial (Stapper) model**: explicitly parameterizes defect *clustering* via a parameter `α`, and is generally considered the most realistic for modern processes.

These models are normally driven by measured particulate defect densities from real fabs. This project instead explores a simplified, illustrative question: *could front-end process control precision itself be modeled as an additional contributor to effective defect density?* Section 6 proposes one possible (non-validated) way to explore this question quantitatively.

---

## 3. Methodology

All simulations were implemented in Python 3, using NumPy for numerical arrays, SciPy for the error function (`erfc`), and Matplotlib for visualization. No proprietary TCAD, SPICE, or fabrication software was used. Source code is available in the accompanying GitHub repository (`src/diffusion.py`, `src/implant.py`, `src/yield_models.py`, `src/combined_demo.py`).

### 3.1 Diffusion Model

The predeposition profile was computed as:

```
C(x, t) = C0 · erfc( x / (2√(D·t)) )
```

and the drive-in profile as:

```
C(x, t) = Q / √(π·D·t) · exp( -x² / (4·D·t) )
```

where `Q` is the total dose delivered by the predeposition step, computed as `Q = (2/√π) · C0 · √(D·t)`.

Diffusivity `D` at each process temperature was computed using the Arrhenius relation:

```
D(T) = D0 · exp( -Ea / (k·T) )
```

**Note on parameter values**: The pre-exponential factor `D0` and activation energy `Ea` used in the current implementation (`D0 = 0.76 cm²/s`, `Ea = 3.46 eV`) are placeholder values used to validate the code's numerical behavior. For a submission-ready version of this paper, these should be replaced with dopant-specific values (e.g., for Boron or Phosphorus in silicon) drawn from a cited source such as Sze's *Physics of Semiconductor Devices* or Plummer, Deal & Griffin's *Silicon VLSI Technology*.

### 3.2 Ion Implantation Model

The implant profile was modeled as a Gaussian distribution centered at the projected range:

```
C(x) = Φ / (√(2π)·ΔRp) · exp( -(x - Rp)² / (2·ΔRp²) )
```

A skew-corrected variant was also implemented, using a piecewise straggle (different effective `ΔRp` above and below the peak) as a simplified approximation of the asymmetry captured more rigorously by a full Pearson-IV distribution.

**Note on parameter values**: `Rp` and `ΔRp` values used for testing (`Rp = 0.08 µm`, `ΔRp = 0.03 µm`) are illustrative placeholders. Real values should be sourced from SRIM/TRIM simulation tables or published implant characterization data for the specific dopant and implant energy being modeled.

### 3.3 Yield Models

Three yield models were implemented as functions of defect density `D0` and die area `A`:

```
Poisson:            Y = exp(-D0·A)
Murphy:              Y = [ (1 - exp(-D0·A)) / (D0·A) ]²
Negative Binomial:   Y = (1 + D0·A/α)^(-α)
```

### 3.4 Combined Process-to-Yield Analysis

To connect the front-end and back-end simulations, the drive-in furnace temperature was swept ±10 K around a nominal value (representing realistic furnace temperature control tolerance), and the resulting junction depth was computed for each temperature using the diffusion model. The standard deviation of junction depth across this sweep, normalized by its mean, was used as a **process variance** metric.

This metric was then fed into a simplified function:

```
D0_effective = D0_base · (1 + k · profile_variance)
```

where `D0_base` is a baseline particulate defect density and `k` is a tunable sensitivity constant. This function is **explicitly illustrative**: it was constructed for this project to demonstrate one plausible way process control could be linked to yield, not derived from or validated against real fabrication data.

---

## 4. Results

### 4.1 Diffusion Profiles

Using the placeholder parameters described in Section 3.1 (predeposition at 950°C for 20 minutes, drive-in at 1100°C for 60 minutes), the simulation produced:

- Predeposition dose: **Q ≈ 5.06 × 10¹⁴ cm⁻²**
- Resulting junction depth after drive-in (against a substrate background doping of 1×10¹⁵ cm⁻³): **xⱼ ≈ 1.43 µm**

The predeposition profile showed the expected erfc shape with a high surface concentration decaying monotonically with depth, while the drive-in profile showed the expected Gaussian shape with a subsurface-shifted peak, consistent with dopant redistribution away from the surface. (See `figures/diffusion_profile.png`.)

### 4.2 Implantation Profiles

Using placeholder implant parameters (dose = 1×10¹⁴ cm⁻², Rp = 0.08 µm, ΔRp = 0.03 µm), the simulation produced:

- Peak concentration: **≈ 1.33 × 10¹⁹ cm⁻³**, located at the projected range as expected.

The skew-corrected profile showed a visibly asymmetric tail extending deeper than the symmetric Gaussian case, qualitatively consistent with the channeling and straggle asymmetries reported in implant literature. (See `figures/implant_profile.png`.)

### 4.3 Yield Curves

For a baseline defect density of 0.5 defects/cm², all three yield models showed the expected qualitative behavior: yield decreases monotonically with increasing die area, with the negative binomial model (α = 2.0) predicting consistently higher yield than the Poisson model at larger die areas — consistent with the clustering assumption reducing the probability of a "fatal" defect landing on any single die. (See `figures/yield_models.png`.)

A simplified gross-die-per-wafer estimate for a 300 mm wafer and 0.5 cm² die area returned approximately **1,319 dies**, before applying any yield factor.

### 4.4 Combined Process-to-Yield Sensitivity

Sweeping the drive-in temperature by ±10 K produced a junction depth standard deviation of approximately **0.088 µm** around a mean of **1.435 µm**, giving a normalized process variance of approximately **0.061**.

When this variance was propagated through the illustrative `D0_effective` function at increasing sensitivity constants (k = 0, 5, 20, 50), the resulting yield curves showed a clear, monotonic yield degradation as `k` increased — by construction, since the model was designed to produce this behavior. (See `figures/process_to_yield_sensitivity.png`.) This result should be read as a demonstration that *such a link is plausible and can be modeled*, not as evidence of its real-world magnitude.

---

## 5. Discussion

The diffusion and implantation simulations reproduced the expected qualitative physics: erfc-shaped predeposition profiles, Gaussian-shaped drive-in and implant profiles, and physically sensible junction depths and peak concentrations for the chosen (placeholder) parameters. This suggests the underlying numerical implementation is correct, even though the specific input constants require replacement with cited literature values before the absolute numbers can be treated as meaningful.

The yield modeling results were consistent with well-established behavior reported in the fabrication literature: yield degrades with die area, and clustering-aware models (negative binomial) predict less severe yield loss than the naive Poisson model at a given defect density.

The combined process-to-yield analysis is the most speculative part of this work. The core idea — that tighter front-end process control should, in principle, reduce parametric variation that could contribute to functional defects — is physically reasonable and discussed qualitatively in the fabrication literature. However, the specific functional form and sensitivity constant `k` used here were chosen for illustrative purposes and are **not derived from measured fab data**. A rigorous treatment would require access to real process control data (e.g., statistical process control charts from an actual furnace) and real defect/yield data correlated against process variation — neither of which was available for this independent project.

---

## 6. Limitations

- All physical constants (D0, Ea for diffusion; Rp, ΔRp for implantation) are illustrative placeholders and require replacement with properly cited literature or SRIM-derived values.
- The diffusion and implantation models are one-dimensional and analytical; they do not capture lateral diffusion, dopant activation/deactivation, or interactions between implant damage and subsequent anneal steps.
- The implant skew correction is a simplified piecewise-Gaussian approximation, not a full Pearson-IV distribution.
- The process-variance-to-defect-density link (Section 3.4, 4.4) is an original illustrative construction for this project and is explicitly **not validated** against real fabrication data.
- No lab access, wafer data, or commercial TCAD/SPICE tools were used; all results are from first-principles numerical simulation only.

---

## 7. Conclusion and Future Work

This project demonstrates a working, from-first-principles simulation pipeline connecting dopant diffusion and ion implantation physics to wafer yield economics, built entirely with open-source Python tools. The individual physics models (diffusion, implantation, yield statistics) reproduce expected qualitative behavior and match standard textbook formulations. The connective process-to-yield model is presented transparently as an illustrative, non-validated construction intended to demonstrate the *plausibility* of linking process control to yield outcomes, rather than a measured result.

Future extensions, contingent on access to better tools or data, could include:

- Replacing placeholder constants with properly cited dopant-specific values.
- Implementing a full Pearson-IV implant distribution using SRIM-derived moments.
- Extending the diffusion model to two dimensions to capture lateral diffusion under masks.
- Validating the process-to-yield link against real statistical process control and yield data, if such data becomes accessible.
- Comparing analytical results against an open-source TCAD tool such as DEVSIM for cross-validation.

---

## References

*(Fill in with full citations before publishing to GitHub — placeholders below indicate the sources this work draws its methodology from.)*

1. Sze, S.M., *Physics of Semiconductor Devices*.
2. Plummer, J.D., Deal, M., Griffin, P.B., *Silicon VLSI Technology: Fundamentals, Practice and Modeling*.
3. Murphy, B.T., "Cost-size optima of monolithic integrated circuits," *Proceedings of the IEEE*, 1964.
4. Stapper, C.H., "Modeling of integrated circuit defect sensitivities," *IBM Journal of Research and Development*.
5. Ziegler, J.F., Biersack, J.P., Littmark, U., *The Stopping and Range of Ions in Solids* (SRIM/TRIM methodology reference).

---

*Code, figures, and reproducibility notebooks accompanying this paper are available in the project's GitHub repository.*
