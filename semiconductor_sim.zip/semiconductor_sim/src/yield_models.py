"""
yield_models.py

Classic wafer/die yield models based on defect density (D0) and
die area (A). These are the standard models taught in VLSI
fabrication economics.

References:
- Murphy, B.T., "Cost-size optima of monolithic integrated circuits", 1964
- Seeds, R.B., "Yield and cost analysis of bipolar LSI", 1967
- Stapper, C.H., negative binomial (clustering) model
"""

import numpy as np


def poisson_yield(D0, A):
    """
    Simplest yield model -- assumes defects are randomly (uniformly)
    distributed across the wafer with no clustering.

    Y = exp(-D0 * A)

    Parameters
    ----------
    D0 : float
        Defect density (defects/cm^2).
    A : float or array_like
        Die area (cm^2).

    Returns
    -------
    Y : float or ndarray
        Yield, fraction between 0 and 1.
    """
    A = np.asarray(A, dtype=float)
    return np.exp(-D0 * A)


def murphy_yield(D0, A):
    """
    Murphy's yield model -- accounts for some defect clustering by
    assuming defect density itself varies across the wafer
    (triangular distribution of D0).

    Y = [ (1 - exp(-D0*A)) / (D0*A) ]^2

    Parameters
    ----------
    D0 : float
        Mean defect density (defects/cm^2).
    A : float or array_like
        Die area (cm^2).

    Returns
    -------
    Y : float or ndarray
        Yield, fraction between 0 and 1.
    """
    A = np.asarray(A, dtype=float)
    x = D0 * A
    # avoid divide-by-zero for very small A
    x = np.where(x == 0, 1e-12, x)
    return ((1.0 - np.exp(-x)) / x) ** 2


def negative_binomial_yield(D0, A, alpha):
    """
    Negative binomial (Stapper) yield model -- more realistic for
    modern processes, explicitly models defect clustering via the
    alpha parameter.

    Y = (1 + D0*A/alpha)^(-alpha)

    As alpha -> infinity, this converges to the Poisson model.
    Smaller alpha means more clustering (typically alpha ~ 0.3 to 5
    for real processes).

    Parameters
    ----------
    D0 : float
        Defect density (defects/cm^2).
    A : float or array_like
        Die area (cm^2).
    alpha : float
        Clustering parameter (dimensionless, > 0).

    Returns
    -------
    Y : float or ndarray
        Yield, fraction between 0 and 1.
    """
    A = np.asarray(A, dtype=float)
    return (1.0 + (D0 * A) / alpha) ** (-alpha)


def gross_die_per_wafer(wafer_diameter_cm, die_area_cm2, edge_loss_factor=1.0):
    """
    Simple estimate of gross dies per wafer (ignores edge-exclusion
    geometry precisely, applies a fudge factor instead). Useful for
    combining yield with a total good-die count.

    A common simplified formula:
        dies ≈ (pi * (D/2)^2) / die_area  -  (pi * D) / sqrt(2*die_area)

    The second term approximates dies lost at the wafer edge.

    Parameters
    ----------
    wafer_diameter_cm : float
        Wafer diameter (cm), e.g. 30 for a 300mm wafer.
    die_area_cm2 : float
        Individual die area (cm^2).
    edge_loss_factor : float
        Multiplier to tune edge-loss severity for sensitivity analysis.

    Returns
    -------
    dies : float
        Estimated gross dies per wafer (not yet multiplied by yield).
    """
    D = wafer_diameter_cm
    A = die_area_cm2
    main_term = (np.pi * (D / 2.0) ** 2) / A
    edge_term = edge_loss_factor * (np.pi * D) / np.sqrt(2.0 * A)
    return max(main_term - edge_term, 0.0)


def defect_density_from_process_variance(D0_base, profile_variance, k):
    """
    A simplified, illustrative link between doping-profile control
    and effective defect density -- this is the "novel" connective
    piece for your paper (Section 5), NOT a validated industrial
    model. State this clearly in the paper.

    Idea: tighter control of the doping profile (lower variance in
    junction depth / straggle across the wafer) should reduce
    parametric-defect-driven yield loss. We model this as a simple
    linear scaling for illustration:

        D0_effective = D0_base * (1 + k * profile_variance)

    Parameters
    ----------
    D0_base : float
        Baseline defect density from purely physical/particulate
        sources (defects/cm^2), independent of doping control.
    profile_variance : float
        A normalized measure of doping profile variability
        (e.g., std. dev. of junction depth across wafer, normalized
        to the mean junction depth). Dimensionless, >= 0.
    k : float
        Sensitivity constant -- how strongly process variance
        translates into effective defect density. Tune this to
        explore "what if" scenarios; there is no single correct
        value without real fab data.

    Returns
    -------
    D0_effective : float
        Effective defect density used to drive yield models.
    """
    return D0_base * (1.0 + k * profile_variance)


if __name__ == "__main__":
    import matplotlib.pyplot as plt

    D0 = 0.5          # defects/cm^2
    alpha = 2.0        # clustering parameter
    areas = np.linspace(0.01, 2.0, 200)  # cm^2

    Y_poisson = poisson_yield(D0, areas)
    Y_murphy = murphy_yield(D0, areas)
    Y_nb = negative_binomial_yield(D0, areas, alpha)

    plt.plot(areas, Y_poisson, label="Poisson")
    plt.plot(areas, Y_murphy, label="Murphy")
    plt.plot(areas, Y_nb, label=f"Negative Binomial (alpha={alpha})")
    plt.xlabel("Die area (cm^2)")
    plt.ylabel("Yield")
    plt.legend()
    plt.title(f"Yield vs Die Area (D0 = {D0} defects/cm^2)")
    plt.tight_layout()
    plt.savefig("../figures/yield_models.png", dpi=150)

    dies = gross_die_per_wafer(30.0, 0.5)
    print(f"Gross dies per 300mm wafer at 0.5 cm^2 die area: {dies:.0f}")
