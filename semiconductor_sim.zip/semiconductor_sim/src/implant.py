"""
implant.py

Simulates ion implantation doping profiles using the standard Gaussian
approximation (projected range Rp, straggle dRp), plus an optional
Pearson-IV-style skew correction for a more realistic asymmetric
profile.

Typical Rp / dRp values for common dopants in silicon at various
implant energies are published in SRIM tables and textbooks
(e.g., Sze, "VLSI Technology"). Pull real numbers from there and
cite them in your paper -- do not present the example values below
as measured data, they're placeholders for testing the code.
"""

import numpy as np


def gaussian_implant_profile(x, dose, Rp, dRp):
    """
    Standard Gaussian ion implantation profile.

    C(x) = (Phi / (sqrt(2*pi)*dRp)) * exp( -(x - Rp)^2 / (2*dRp^2) )

    Parameters
    ----------
    x : array_like
        Depth into the wafer (cm).
    dose : float
        Implant dose, Phi (ions/cm^2).
    Rp : float
        Projected range -- depth of peak concentration (cm).
    dRp : float
        Straggle -- standard deviation of the distribution (cm).

    Returns
    -------
    C : ndarray
        Concentration profile (cm^-3).
    """
    x = np.asarray(x, dtype=float)
    prefactor = dose / (np.sqrt(2.0 * np.pi) * dRp)
    return prefactor * np.exp(-((x - Rp) ** 2) / (2.0 * dRp ** 2))


def skewed_implant_profile(x, dose, Rp, dRp, gamma=0.0):
    """
    A simple skew-corrected implant profile using a piecewise-Gaussian
    (different effective straggle on either side of the peak), which
    approximates the asymmetry a full Pearson-IV distribution captures
    without needing the higher-order moment solver.

    gamma > 0 skews the profile deeper (tail extends beyond Rp);
    gamma < 0 skews it shallower. gamma = 0 reduces to a symmetric
    Gaussian.

    This is a simplified teaching approximation -- for a rigorous
    treatment, implement the full Pearson-IV distribution using its
    four moments (Rp, dRp, skewness gamma1, kurtosis beta2) from
    SRIM-derived tables.

    Parameters
    ----------
    x : array_like
        Depth (cm).
    dose : float
        Implant dose (ions/cm^2).
    Rp : float
        Projected range (cm).
    dRp : float
        Nominal straggle (cm).
    gamma : float
        Skew parameter, roughly in [-0.5, 0.5]. 0 = symmetric.

    Returns
    -------
    C : ndarray
        Concentration profile (cm^-3).
    """
    x = np.asarray(x, dtype=float)
    dRp_shallow = dRp * (1.0 - gamma)
    dRp_deep = dRp * (1.0 + gamma)

    C = np.empty_like(x)
    shallow_mask = x <= Rp
    deep_mask = ~shallow_mask

    prefactor_shallow = dose / (np.sqrt(2.0 * np.pi) * dRp_shallow)
    prefactor_deep = dose / (np.sqrt(2.0 * np.pi) * dRp_deep)

    C[shallow_mask] = prefactor_shallow * np.exp(
        -((x[shallow_mask] - Rp) ** 2) / (2.0 * dRp_shallow ** 2)
    )
    C[deep_mask] = prefactor_deep * np.exp(
        -((x[deep_mask] - Rp) ** 2) / (2.0 * dRp_deep ** 2)
    )
    return C


def peak_concentration(dose, dRp):
    """Peak concentration at x = Rp, useful as a quick sanity check."""
    return dose / (np.sqrt(2.0 * np.pi) * dRp)


if __name__ == "__main__":
    import matplotlib.pyplot as plt

    # Example placeholder values (cm) -- replace with cited SRIM/textbook
    # values for Boron or Phosphorus at a specific implant energy.
    dose = 1e14        # ions/cm^2
    Rp = 0.08e-4        # 0.08 um projected range
    dRp = 0.03e-4        # 0.03 um straggle

    x = np.linspace(0, 3e-4, 500)

    C_gauss = gaussian_implant_profile(x, dose, Rp, dRp)
    C_skew = skewed_implant_profile(x, dose, Rp, dRp, gamma=0.3)

    plt.semilogy(x * 1e4, C_gauss, label="Symmetric Gaussian")
    plt.semilogy(x * 1e4, C_skew, label="Skewed (gamma=0.3)")
    plt.axvline(Rp * 1e4, color="gray", linestyle="--", label="Rp")
    plt.xlabel("Depth (um)")
    plt.ylabel("Concentration (cm^-3)")
    plt.legend()
    plt.title("Ion Implantation Profiles")
    plt.tight_layout()
    plt.savefig("../figures/implant_profile.png", dpi=150)
    print(f"Peak concentration = {peak_concentration(dose, dRp):.3e} cm^-3")
