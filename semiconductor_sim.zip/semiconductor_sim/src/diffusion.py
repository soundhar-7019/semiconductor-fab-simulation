"""
diffusion.py

Simulates dopant diffusion profiles in silicon using Fick's second law
solutions for two standard fabrication steps:

1. Predeposition (constant surface concentration source)
   -> complementary error function (erfc) profile

2. Drive-in diffusion (fixed dose, limited source)
   -> Gaussian profile

Also includes the Arrhenius relation for temperature-dependent
diffusivity, since D is never a constant in real processes.

References for typical constants:
- Sze, S.M., "Physics of Semiconductor Devices"
- Plummer, Deal, Griffin, "Silicon VLSI Technology"
(Use these as citations in your paper, not this code.)
"""

import numpy as np
from scipy.special import erfc

# Boltzmann constant in eV/K
K_BOLTZMANN_EV = 8.617333262e-5


def arrhenius_diffusivity(D0, Ea, T):
    """
    Compute diffusion coefficient D at temperature T using the
    Arrhenius relation.

    Parameters
    ----------
    D0 : float
        Pre-exponential factor (cm^2/s). Dopant + material dependent.
    Ea : float
        Activation energy (eV).
    T : float
        Temperature in Kelvin.

    Returns
    -------
    D : float
        Diffusivity in cm^2/s at temperature T.
    """
    return D0 * np.exp(-Ea / (K_BOLTZMANN_EV * T))


def predeposition_profile(x, t, D, C0):
    """
    Constant-source diffusion profile (predeposition step).

    C(x, t) = C0 * erfc(x / (2 * sqrt(D*t)))

    Parameters
    ----------
    x : array_like
        Depth into the wafer (cm).
    t : float
        Diffusion time (s).
    D : float
        Diffusivity at the process temperature (cm^2/s).
    C0 : float
        Surface concentration, set by solid solubility limit (cm^-3).

    Returns
    -------
    C : ndarray
        Dopant concentration vs depth (cm^-3).
    """
    x = np.asarray(x, dtype=float)
    denom = 2.0 * np.sqrt(D * t)
    return C0 * erfc(x / denom)


def predeposition_dose(D, t, C0):
    """
    Total dose (dopant atoms per cm^2) delivered by a predeposition
    step. Needed as the Q input for the following drive-in step.

    Q = (2/sqrt(pi)) * C0 * sqrt(D*t)
    """
    return (2.0 / np.sqrt(np.pi)) * C0 * np.sqrt(D * t)


def drive_in_profile(x, t, D, Q):
    """
    Limited-source (Gaussian) diffusion profile, used to model the
    drive-in step after predeposition, where no more dopant enters
    from the surface -- the existing dose Q simply redistributes.

    C(x, t) = Q / sqrt(pi * D * t) * exp( -x^2 / (4*D*t) )

    Parameters
    ----------
    x : array_like
        Depth into the wafer (cm).
    t : float
        Drive-in time (s).
    D : float
        Diffusivity at the drive-in temperature (cm^2/s).
    Q : float
        Total dose from the predeposition step (cm^-2).

    Returns
    -------
    C : ndarray
        Dopant concentration vs depth (cm^-3).
    """
    x = np.asarray(x, dtype=float)
    return (Q / np.sqrt(np.pi * D * t)) * np.exp(-(x ** 2) / (4.0 * D * t))


def junction_depth(x, C, C_background):
    """
    Estimate the junction depth: the depth at which the diffused
    dopant concentration equals the substrate background doping
    (this is where the p-n junction forms).

    Parameters
    ----------
    x : array_like
        Depth array (cm), same length as C.
    C : array_like
        Concentration profile (cm^-3), same length as x.
    C_background : float
        Substrate background doping concentration (cm^-3).

    Returns
    -------
    xj : float or None
        Estimated junction depth (cm). None if C never crosses
        C_background within the given x range.
    """
    x = np.asarray(x, dtype=float)
    C = np.asarray(C, dtype=float)

    below = np.where(C <= C_background)[0]
    if len(below) == 0:
        return None  # profile never drops to background in this range

    idx = below[0]
    if idx == 0:
        return x[0]

    # linear interpolation between the two bracketing points for a
    # smoother estimate than just picking the nearest grid point
    x1, x2 = x[idx - 1], x[idx]
    C1, C2 = C[idx - 1], C[idx]
    if C1 == C2:
        return x1
    frac = (C_background - C1) / (C2 - C1)
    return x1 + frac * (x2 - x1)


if __name__ == "__main__":
    # quick sanity check / example usage
    import matplotlib.pyplot as plt

    # Example: Boron predeposition then drive-in
    D0, Ea = 0.76, 3.46          # example Arrhenius params (cm^2/s, eV) -- replace with cited literature values
    T_pre = 1223.0                # 950 C predep
    T_drive = 1373.0              # 1100 C drive-in
    t_pre = 20 * 60.0             # 20 min
    t_drive = 60 * 60.0           # 60 min
    C0 = 2e20                     # solid solubility limit for Boron, cm^-3 (example)
    C_background = 1e15           # substrate doping, cm^-3

    D_pre = arrhenius_diffusivity(D0, Ea, T_pre)
    D_drive = arrhenius_diffusivity(D0, Ea, T_drive)

    x = np.linspace(0, 3e-4, 500)  # 0 to 3 micron, in cm

    C_pre = predeposition_profile(x, t_pre, D_pre, C0)
    Q = predeposition_dose(D_pre, t_pre, C0)
    C_drive = drive_in_profile(x, t_drive, D_drive, Q)

    xj = junction_depth(x, C_drive, C_background)

    plt.semilogy(x * 1e4, C_pre, label="Predeposition (erfc)")
    plt.semilogy(x * 1e4, C_drive, label="Drive-in (Gaussian)")
    plt.axhline(C_background, color="gray", linestyle="--", label="Substrate doping")
    if xj is not None:
        plt.axvline(xj * 1e4, color="red", linestyle=":", label=f"Junction depth = {xj*1e4:.3f} um")
    plt.xlabel("Depth (um)")
    plt.ylabel("Concentration (cm^-3)")
    plt.legend()
    plt.title("Dopant Diffusion Profiles")
    plt.tight_layout()
    plt.savefig("../figures/diffusion_profile.png", dpi=150)
    print(f"Predeposition dose Q = {Q:.3e} cm^-2")
    print(f"Junction depth = {xj*1e4:.4f} um" if xj else "No junction found in range")
