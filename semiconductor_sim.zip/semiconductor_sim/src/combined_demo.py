"""
combined_demo.py

Ties diffusion.py, implant.py, and yield_models.py together to
produce the "process -> yield" sensitivity analysis that is the
novel connective piece of the paper (Section 5).

Run this from inside src/:
    python combined_demo.py

It will save plots into ../figures/
"""

import numpy as np
import matplotlib.pyplot as plt

from diffusion import arrhenius_diffusivity, drive_in_profile, predeposition_profile, \
    predeposition_dose, junction_depth
from yield_models import poisson_yield, murphy_yield, negative_binomial_yield, \
    defect_density_from_process_variance


def junction_depth_vs_temperature(T_range, t_drive, D0, Ea, Q, C_background,
                                   x_max=3e-4, n_points=500):
    """
    Sweep drive-in temperature and compute resulting junction depth
    for each, to show how tightly (or loosely) temperature control
    translates into junction depth variability.
    """
    x = np.linspace(0, x_max, n_points)
    xj_list = []
    for T in T_range:
        D = arrhenius_diffusivity(D0, Ea, T)
        C = drive_in_profile(x, t_drive, D, Q)
        xj = junction_depth(x, C, C_background)
        xj_list.append(xj if xj is not None else np.nan)
    return np.array(xj_list)


def main():
    # ---- Step 1: baseline process parameters (placeholders --
    # replace with literature-cited values for your paper) ----
    D0_arr, Ea = 0.76, 3.46         # Arrhenius params (cm^2/s, eV)
    C0 = 2e20                        # predep surface concentration (cm^-3)
    C_background = 1e15              # substrate doping (cm^-3)
    t_pre = 20 * 60.0
    T_pre = 1223.0
    t_drive = 60 * 60.0
    T_drive_nominal = 1373.0

    D_pre = arrhenius_diffusivity(D0_arr, Ea, T_pre)
    Q = predeposition_dose(D_pre, t_pre, C0)

    # ---- Step 2: sweep drive-in temperature +/- 10K to simulate
    # realistic furnace temperature control tolerance ----
    T_range = np.linspace(T_drive_nominal - 10, T_drive_nominal + 10, 21)
    xj_values = junction_depth_vs_temperature(
        T_range, t_drive, D0_arr, Ea, Q, C_background
    )

    xj_mean = np.nanmean(xj_values)
    xj_std = np.nanstd(xj_values)
    profile_variance = xj_std / xj_mean  # normalized variability

    print(f"Junction depth: mean = {xj_mean*1e4:.4f} um, "
          f"std = {xj_std*1e4:.4f} um, normalized variance = {profile_variance:.4f}")

    # ---- Step 3: plot junction depth sensitivity to temperature ----
    plt.figure()
    plt.plot(T_range, xj_values * 1e4, marker="o")
    plt.xlabel("Drive-in temperature (K)")
    plt.ylabel("Junction depth (um)")
    plt.title("Junction Depth Sensitivity to Furnace Temperature")
    plt.tight_layout()
    plt.savefig("../figures/junction_depth_vs_temperature.png", dpi=150)
    plt.close()

    # ---- Step 4: link process variance to effective defect density,
    # then to yield (Section 5 of the paper) ----
    D0_base = 0.3  # baseline particulate defect density, defects/cm^2
    k_values = [0.0, 5.0, 20.0, 50.0]  # sensitivity constants to explore
    areas = np.linspace(0.01, 2.0, 200)

    plt.figure()
    for k in k_values:
        D0_eff = defect_density_from_process_variance(D0_base, profile_variance, k)
        Y = negative_binomial_yield(D0_eff, areas, alpha=2.0)
        plt.plot(areas, Y, label=f"k={k} (D0_eff={D0_eff:.3f})")

    plt.xlabel("Die area (cm^2)")
    plt.ylabel("Yield (negative binomial model)")
    plt.title("Effect of Process-Variance Sensitivity (k) on Yield")
    plt.legend()
    plt.tight_layout()
    plt.savefig("../figures/process_to_yield_sensitivity.png", dpi=150)
    plt.close()

    print("Saved figures to ../figures/")
    print("NOTE: k values above are illustrative only -- justify or replace")
    print("them with cited data/assumptions in your paper's methodology section.")


if __name__ == "__main__":
    main()
